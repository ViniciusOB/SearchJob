<?php
include 'config.php';

// Verifica se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $senha = $_POST['senha'];  // Senha armazenada conforme digitada
    $tipo_conta = $_POST['tipo_conta'];

    // Prepara uma declaração de inserção
    $sql = "INSERT INTO usuarios (email, senha, tipo_conta) VALUES (?, ?, ?)";

    if ($stmt = $conn->prepare($sql)) {
        // Liga as variáveis à declaração preparada como parâmetros
        $stmt->bind_param("sss", $email, $senha, $tipo_conta);

        // Tenta executar a declaração preparada
        if ($stmt->execute()) {
            echo "Usuário cadastrado com sucesso.";
            // Redireciona para a página de login
            header("Location: login.php");
            exit;
        } else {
            echo "Erro: Não foi possível cadastrar o usuário. " . $stmt->error;
        }

        // Fecha a declaração
        $stmt->close();
    } else {
        echo "Erro: Não foi possível preparar a declaração. " . $conn->error;
    }

    // Fecha a conexão
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EstudeAqui - Cadastro</title>
    <link rel="stylesheet" href="CSS/style.css">
    <style>
        /* Basic Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #fff;
        }

        .navbar {
            background-color: #000;
            padding: 1rem 0;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
        }

        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
            text-decoration: none;
            color: #d6a4d0; /* Roxo */
        }

        .navbar-nav {
            list-style: none;
            display: flex;
            gap: 2rem;
        }

        .nav-item {
            margin-left: 1.5rem;
        }

        .nav-link {
            text-decoration: none;
            color: #fff;
            transition: color 0.3s;
        }

        .nav-link:hover {
            color: #d6a4d0;
        }

        .donito-link {
            background-color: #d6a4d0; /* Roxo */
            color: #fff;
            padding: 0.5rem 1rem;
            border-radius: 0.5rem;
            text-decoration: none;
            font-weight: bold;
        }

        .donito-link:hover {
            background-color: #6A0D91; /* Roxo Escuro */
        }

        .search-form {
            display: flex;
            align-items: center;
        }

        .search-input {
            border: none;
            background-color: #333;
            color: #fff;
            padding: 0.5rem;
            border-radius: 0.25rem;
        }

        .search-input:focus {
            outline: none;
            background-color: #444;
        }

        .search-button {
            background: none;
            border: none;
            color: #fff;
            cursor: pointer;
        }

        .search-button:hover {
            color: #d6a4d0;
        }

        .ciano {
            color: pink;
        }

        .split-container {
            display: flex;
            height: 100vh;
        }

        .left-half, .right-half {
            width: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .left-half {
            background-color: #000;
            color: #fff;
            flex-direction: column;
            padding: 4rem 3rem;
        }

        .left-half h1 {
            font-size: 2.5rem;
            margin-bottom: 1.5rem;
            text-align: center;
        }

        .left-half p {
            font-size: 1.2rem;
            margin-bottom: 2.5rem;
            text-align: center;
            line-height: 1.6;
        }

        .get-started-button {
            background-color: rgb(0, 106, 155);
            border: none;
            color: #000;
            cursor: pointer;
            padding: 1rem 2rem;
            border-radius: 0.5rem;
            transition: background-color 0.3s;
            font-size: 1.1rem;
        }

        .get-started-button:hover {
            background-color: #d6a4d0;
        }

        .right-half {
            background-color: #000;
            display: flex;
            justify-content: center;
            align-items: center;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            padding: 3rem;
        }

        .right-half img {
            max-width: 100%;
            height: auto;
            border-radius: 50%;
        }

        /* Form Styles */
        .form-container {
            width: 100%;
            max-width: 400px;
            padding: 2rem;
            background-color: #222;
            border-radius: 0.5rem;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .form-container label {
            display: block;
            margin-bottom: 0.5rem;
        }

        .form-container input, .form-container select {
            width: 100%;
            padding: 0.5rem;
            margin-bottom: 1rem;
            border: none;
            border-radius: 0.25rem;
            background-color: #333;
            color: #fff;
        }

        .form-container input[type="submit"] {
            background-color: #d6a4d0;
            color: #000;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .form-container input[type="submit"]:hover {
            background-color: rgb(0, 106, 155);
        }

        .assinatura-button {
            background-color: #40E0D0;
            border: none;
            color: #000;
            cursor: pointer;
            padding: 0.5rem 1.5rem;
            border-radius: 0.5rem;
            transition: background-color 0.3s;
            font-size: 1rem;
            margin-top: 1rem;
        }

        .assinatura-button:hover {
            background-color: #00CCCC;
        }

        /* Estilo adicional para a imagem */
        .split-container .left-half img {
            max-width: 300px; 
            height: auto;
            display: block; 
            margin-top: 10px; 
        }

        .footertext-centerpy-3mt-4{

        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <a href="#" class="navbar-brand">EstudeAqui</a>
            <ul class="navbar-nav">
                <li class="nav-item"><a href="home.php" class="nav-link">Home</a></li>
                <li class="nav-item"><a href="#" class="nav-link">Sobre nós</a></li>             
                <li class="nav-item"><a href="login.php" class="donito-link">Login</a></li> 
            </ul>
        </div>
    </nav>

    <div class="split-container">
        <div class="left-half">
            <img src="img/sla.png" alt="Imagem de exemplo">
            <h1>Bem-vindo ao EstudeAqui</h1>
            <p>Cadastre-se para acessar nossos quizzes, lives e muito mais.</p>
        </div>

        <div class="right-half">
            <div class="form-container">
                <form action="cadastro.php" method="post">
                    <label for="email">Email:</label>
                    <input type="email" name="email" required><br>

                    <label for="senha">Senha:</label>
                    <input type="password" name="senha" required><br>

                    <label for="tipo_conta">Tipo de Conta:</label>
                    <select name="tipo_conta" required>
                        <option value="aluno">Aluno</option>
                    </select><br>

                    <input type="submit" value="Cadastrar">
                </form>
                <center><p>&copy; 2024 EstudeAqui</p></center>
            </div>
        </div>
    </div>

   
</body>
</html>
