<?php
// Incluir o arquivo com a conexão com o banco de dados
include_once './config.php';

// Receber o id enviado pelo JavaScript
$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);

// Acessa o IF quando existe o id do evento
if (!empty($id)) {
    // Criar a QUERY para apagar evento no banco de dados
    $query_apagar_event = "DELETE FROM agenda WHERE agenda_id=?";
    
    // Prepara a QUERY
    $stmt = $conn->prepare($query_apagar_event);

    // Substituir o link pelo valor
    $stmt->bind_param('i', $id);

    // Verificar se conseguiu apagar corretamente
    if ($stmt->execute()) {
        $retorna = ['status' => true, 'msg' => 'Evento apagado com sucesso!'];
    } else {
        $retorna = ['status' => false, 'msg' => 'Erro: Evento não apagado!'];
    }

} else { // Acessa o ELSE quando o id está vazio
    $retorna = ['status' => false, 'msg' => 'Erro: Necessário enviar o id do evento!'];
}

// Converter o array em objeto e retornar para o JavaScript
echo json_encode($retorna);

// Fecha a declaração
$stmt->close();

// Fecha a conexão
$conn->close();
?>
