<?php
$servername = "45.152.44.154";
$username = "u451416913_2024grupo07";
$password = "Grupo07@123";
$dbname = "u451416913_2024grupo07";

// Cria a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}


?>
