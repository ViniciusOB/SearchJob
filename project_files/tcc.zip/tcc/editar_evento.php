<?php
// Incluir o arquivo com a conexão com o banco de dados
include_once './config.php';

// Filtra e valida os dados recebidos
$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

if ($dados) {
    // Prepara a consulta SQL para edição
    $query_edit_event = "UPDATE agenda SET nome_materia=?, descricao=?, link_live=?, horario=?, cor=? 
                         WHERE agenda_id=?";
    
    // Prepara a consulta
    $stmt = $conn->prepare($query_edit_event);
    
    // Faz a ligação dos parâmetros com os valores recebidos
    $stmt->bind_param("sssssi", 
        $dados['edit_nome_materia'], 
        $dados['edit_descricao'], 
        $dados['edit_link_live'], 
        $dados['edit_horario'], 
        $dados['edit_cor'],
        $dados['edit_id']
    );

    // Executa a consulta e verifica se foi bem-sucedida
    if ($stmt->execute()) {
        $retorna = ['status' => true, 'msg' => 'Evento editado com sucesso!'];
    } else {
        $retorna = ['status' => false, 'msg' => 'Erro: Evento não editado!'];
    }

    echo json_encode($retorna);

    // Fecha a declaração
    $stmt->close();
}

// Fecha a conexão
$conn->close();
?>
