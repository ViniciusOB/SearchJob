<?php

include_once './config.php';

$query = "SELECT agenda_id AS id, nome_materia AS title, descricao, link_live, horario
 AS start, cor AS backgroundColor, professor_id FROM agenda";
$result = $conn->query($query);

$events = [];

while ($row = $result->fetch_assoc()) {
    $events[] = $row;
}

echo json_encode($events);

$conn->close();
?>
