<?php

include_once './config.php';

// Filtra e valida os dados recebidos
$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

if ($dados) {
    // Prepara a consulta SQL para inserção
    $query_cad_event = "INSERT INTO agenda (nome_materia, descricao, link_live, horario, cor, professor_id) 
                        VALUES ('" . $nome_materia ."', '" . $descricao . "','" . $link_live . "','" . $horario . "','" . $cor . "','" . $professor_id "')";
    // Prepara a consulta
   // $stmt = $conn->prepare($query_cad_event);
    
    // Faz a ligação dos parâmetros com os valores recebidos
    $stmt->bind_param("sssssi", 
        $dados['cad_nome_materia'], 
        $dados['cad_descricao'], 
        $dados['cad_link_live'], 
        $dados['cad_horario'], 
        $dados['cad_cor'],
        $dados['cad_professor_id']
    );

    // Executa a consulta e verifica se foi bem-sucedida
    if ($stmt->execute()) {
        // Retorna uma resposta JSON em caso de sucesso
        $retorna = [
            'status' => true, 
            'msg' => 'Evento cadastrado com sucesso!',
            'id' => $conn->insert_id,
            'nome_materia' => $dados['cad_nome_materia'],
            'descricao' => $dados['cad_descricao'],
            'link_live' => $dados['cad_link_live'],
            'horario' => $dados['cad_horario'],
            'cor' => $dados['cad_cor'],
            'professor_id' => $dados['cad_professor_id']
        ];
    } else {
        // Retorna uma resposta JSON em caso de erro na execução da query
        $retorna = ['status' => false, 'msg' => 'Erro: Evento não cadastrado!'];
    }

    echo json_encode($retorna);

    // Fecha a declaração
    $stmt->close();
}

// Fecha a conexão
$conn->close();
?>
