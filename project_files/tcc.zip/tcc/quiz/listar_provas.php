<?php
include '../config.php'; // Inclua o arquivo de configuração para conectar ao banco de dados

// Consultar as provas
$sql = "SELECT provas.prova_id, provas.titulo, disciplinas.nome AS disciplina 
        FROM provas 
        JOIN disciplinas ON provas.disciplina_id = disciplinas.disciplina_id";

// Execute a consulta
$result = $conn->query($sql);

// Verifique se a consulta retornou resultados
if ($result === false) {
    die("Erro ao buscar provas: " . $conn->error);
}

// Armazenar todas as provas em um array
$provas = [];
while ($row = $result->fetch_assoc()) {
    $provas[] = $row;
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Listar Provas</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <h1 class="mt-5">Provas Criadas</h1>
    <ul class="list-group mt-3">
        <?php foreach ($provas as $prova): ?>
            <li class="list-group-item">
                <?= htmlspecialchars($prova['disciplina']) ?> - <?= htmlspecialchars($prova['titulo']) ?>
                <a href="editar_prova.php?prova_id=<?= htmlspecialchars($prova['prova_id']) ?>" class="btn btn-primary float-right">Editar</a>
                <a href="excluir_prova.php?prova_id=<?= htmlspecialchars($prova['prova_id']) ?>" class="btn btn-danger float-right" onclick="return confirm('Tem certeza de que deseja excluir esta prova?');">Excluir</a>
            </li>
        <?php endforeach; ?>
    </ul>
    <a href="inicial.php" class="btn btn-info mt-3">Voltar ao Menu Principal</a>
</div>
</body>
</html>
