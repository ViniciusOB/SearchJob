<?php
include '../config.php'; // Inclua o arquivo de configuração com a conexão ao banco

// Tratamento do formulário de criação de prova
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $disciplina_id = $_POST['disciplina'];
    $titulo = $_POST['titulo'];

    // Usa prepared statements para evitar SQL injection
    $sql = "INSERT INTO provas (disciplina_id, titulo) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('is', $disciplina_id, $titulo);

    if ($stmt->execute()) {
        $prova_id = $stmt->insert_id; // Obtém o ID da última inserção
        header("Location: adicionar_perguntas.php?prova_id=$prova_id");
        exit();
    } else {
        echo "Erro ao criar a prova: " . $stmt->error;
    }
}

// Busca disciplinas para o select
$sql = "SELECT * FROM disciplinas";
$result = $conn->query($sql);
if (!$result) {
    die("Erro ao buscar disciplinas: " . $conn->error);
}
$disciplinas = $result->fetch_all(MYSQLI_ASSOC);

// Busca provas existentes para listagem
$sql = "SELECT provas.prova_id, disciplinas.nome as disciplina, provas.titulo 
        FROM provas 
        JOIN disciplinas ON provas.disciplina_id = disciplinas.disciplina_id";
$result = $conn->query($sql);
if (!$result) {
    die("Erro ao buscar provas: " . $conn->error);
}
$provas = $result->fetch_all(MYSQLI_ASSOC);

// Fecha a conexão
$conn->close();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Criar e Listar Provas</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <h1 class="mt-5">Criar Nova Prova</h1>
    <form method="post" class="mt-3">
        <div class="form-group">
            <label for="disciplina">Disciplina</label>
            <select name="disciplina" class="form-control" id="disciplina" required>
                <?php foreach ($disciplinas as $disciplina) : ?>
                    <option value="<?= htmlspecialchars($disciplina['disciplina_id']) ?>"><?= htmlspecialchars($disciplina['nome']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label for="titulo">Título da Prova</label>
            <input type="text" class="form-control" id="titulo" name="titulo" required>
        </div>
        <button type="submit" class="btn btn-primary">Criar Prova e Adicionar Perguntas</button>
    </form>

  
    <a href="inicial.php" class="btn btn-info mt-3">Voltar ao Menu Principal</a>
</div>

</body>
</html>
