<?php
include '../config.php'; // Inclua o arquivo de configuração para conectar ao banco de dados

// Verificar se o parâmetro prova_id foi passado na URL
if (!isset($_GET['prova_id']) || empty($_GET['prova_id'])) {
    die("ID da prova não fornecido.");
}

$prova_id = (int)$_GET['prova_id'];

// Começar uma transação
$conn->begin_transaction();

try {
    // Excluir perguntas associadas
    $sql = "DELETE FROM perguntas WHERE prova_id = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Erro ao preparar a consulta: " . $conn->error);
    }
    $stmt->bind_param("i", $prova_id);
    $stmt->execute();

    // Excluir a prova
    $sql = "DELETE FROM provas WHERE prova_id = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Erro ao preparar a consulta: " . $conn->error);
    }
    $stmt->bind_param("i", $prova_id);
    $stmt->execute();

    // Confirmar a transação
    $conn->commit();

    // Redirecionar para a página de listagem de provas
    header("Location: listar_provas.php");
    exit();

} catch (Exception $e) {
    // Se ocorrer um erro, reverter a transação
    $conn->rollback();
    die("Erro ao excluir a prova: " . $e->getMessage());
}

$conn->close();
?>
