<?php
include '../config.php';
session_start();

$prova_id = $_GET['prova_id'] ?? null;
if (!$prova_id) {
    header('Location: provas_aluno.php');
    exit();
}

// Verificar se a conexão foi estabelecida corretamente
if (!$conn) {
    die("Falha na conexão com o banco de dados: " . $conn->connect_error);
}

// Buscar perguntas da prova
$sql = "SELECT * FROM perguntas WHERE prova_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $prova_id);
$stmt->execute();
$result = $stmt->get_result();
$perguntas = $result->fetch_all(MYSQLI_ASSOC);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $respostas = $_POST['respostas'] ?? [];
    $score = 0;
    foreach ($respostas as $pergunta_id => $resposta) {
        $sql = "SELECT resposta_correta FROM perguntas WHERE pergunta_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $pergunta_id);
        $stmt->execute();
        $stmt->bind_result($correta);
        $stmt->fetch();
        $stmt->close();

        if ($correta == $resposta) {
            $score++;
        }
    }
    $totalPerguntas = count($perguntas);
    $percentual = ($score / $totalPerguntas) * 100;

    $_SESSION['resultado'] = "Você acertou $score de $totalPerguntas perguntas ($percentual%).";
    header('Location: resultado_prova.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Realizar Prova</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <h1 class="mt-5">Realizar Prova</h1>
    <form method="post" class="mt-3">
        <?php foreach ($perguntas as $index => $pergunta): ?>
            <div class="card mb-3">
                <div class="card-header">Pergunta <?= $index + 1 ?></div>
                <div class="card-body">
                    <p><?= htmlspecialchars($pergunta['pergunta']) ?></p>
                    <div class="form-group">
                        <?php foreach (['a', 'b', 'c', 'd'] as $option): ?>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="respostas[<?= $pergunta['pergunta_id'] ?>]" id="resposta_<?= $pergunta['pergunta_id'] ?>_<?= $option ?>" value="<?= strtoupper($option) ?>" required>
                                <label class="form-check-label" for="resposta_<?= $pergunta['pergunta_id'] ?>_<?= $option ?>">
                                    <?= htmlspecialchars($pergunta["opcao_$option"]) ?>
                                </label>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
        <button type="submit" class="btn btn-success">Enviar Respostas</button>
    </form>
</div>
</body>
</html>
