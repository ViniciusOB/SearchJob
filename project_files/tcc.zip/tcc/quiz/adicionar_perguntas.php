<?php
include '../config.php'; // Inclua o arquivo de configuração

$prova_id = $_GET['prova_id'] ?? null;

if ($_SERVER["REQUEST_METHOD"] == "POST" && $prova_id) {
    $pergunta = $_POST['pergunta'];
    $opcao_a = $_POST['opcao_a'];
    $opcao_b = $_POST['opcao_b'];
    $opcao_c = $_POST['opcao_c'];
    $opcao_d = $_POST['opcao_d'];
    $resposta_correta = $_POST['resposta_correta'];

    // Prepara e executa a consulta
    $sql = "INSERT INTO perguntas (prova_id, pergunta, opcao_a, opcao_b, opcao_c, opcao_d, resposta_correta) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("issssss", $prova_id, $pergunta, $opcao_a, $opcao_b, $opcao_c, $opcao_d, $resposta_correta);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            echo "<script>alert('Pergunta adicionada com sucesso!');</script>";
        } else {
            echo "<script>alert('Erro ao adicionar pergunta.');</script>";
        }
        $stmt->close();
    } else {
        echo "<script>alert('Erro ao preparar a consulta.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Adicionar Perguntas</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <h1 class="mt-5">Adicionar Perguntas à Prova</h1>
    <form method="post" class="mt-3">
        <input type="hidden" name="prova_id" value="<?= htmlspecialchars($prova_id) ?>">
        <div class="form-group">
            <label for="pergunta">Pergunta</label>
            <input type="text" class="form-control" id="pergunta" name="pergunta" required>
        </div>
        <div class="form-group">
            <label>Opção A</label>
            <input type="text" class="form-control" name="opcao_a" required>
        </div>
        <div class="form-group">
            <label>Opção B</label>
            <input type="text" class="form-control" name="opcao_b" required>
        </div>
        <div class="form-group">
            <label>Opção C</label>
            <input type="text" class="form-control" name="opcao_c" required>
        </div>
        <div class="form-group">
            <label>Opção D</label>
            <input type="text" class="form-control" name="opcao_d" required>
        </div>
        <div class="form-group">
            <label>Resposta Correta</label>
            <select class="form-control" name="resposta_correta" required>
                <option value="A">A</option>
                <option value="B">B</option>
                <option value="C">C</option>
                <option value="D">D</option>
            </select>
        </div>
        <button type="submit" class="btn btn-success">Adicionar Pergunta</button>
        <!-- Botão para voltar ao menu principal -->
        <a href="inicial.php" class="btn btn-info mt-3">Voltar ao Menu Principal</a>
    </form>
</div>
</body>
</html>
