<?php
session_start();

// Verifica se há um resultado de prova na sessão
if (!isset($_SESSION['resultado'])) {
    header('Location: provas_aluno.php');
    exit();
}

// Recupera o resultado da prova da sessão e limpa a sessão
$resultado = $_SESSION['resultado'];
session_unset(); // Limpa todas as variáveis de sessão
session_destroy(); // Destroi a sessão
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Resultado da Prova</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <h1 class="mt-5">Resultado da Prova</h1>
    <div class="alert alert-info" role="alert">
        <?= htmlspecialchars($resultado, ENT_QUOTES, 'UTF-8') ?>
    </div>
    <a href="provas_aluno.php" class="btn btn-primary">Voltar às Provas</a>
</div>
</body>
</html>
