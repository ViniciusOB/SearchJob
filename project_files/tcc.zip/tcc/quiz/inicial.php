<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="quiz.css">

    <title>Sistema Escolar</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    
</head>
<body>
<div class="container">
    <h1 class="my-4 text-center">Bem-vindo ao Sistema de Provas EAD</h1>
    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="card text-white bg-primary o-hidden h-100">
                <div class="card-body">
                    <div class="card-body-icon">
                        <i class="fas fa-fw fa-user-graduate"></i>
                    </div>
                    <div class="card-title">Menu do Aluno</div>
                    <a href="provas_aluno.php" class="btn btn-light btn-block">Realizar Provas</a>
                </div>
            </div>
        </div>
        <div class="col-md-6 mb-4">
            <div class="card text-white bg-success o-hidden h-100">
                <div class="card-body">
                    <div class="card-body-icon">
                        <i class="fas fa-fw fa-chalkboard-teacher"></i>
                    </div>
                    <div class="card-title">Menu do Professor</div>
                    <a href="criar_prova.php" class="btn btn-light btn-block">Criar Provas</a>
                    <a href="listar_provas.php" class="btn btn-light btn-block mt-2">Listar Provas</a>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
</body>
</html>
