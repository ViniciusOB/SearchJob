<?php

session_start(); // Iniciar a sessão para usar mensagens de sucesso

// Inclua o arquivo de configuração
include '../config.php'; 

// Verifique se a conexão foi estabelecida corretamente
if (!$conn) {
    die("Falha na conexão com o banco de dados: " . $conn->connect_error);
}

// Obtenha o ID da prova a partir da URL
$prova_id = isset($_GET['prova_id']) ? (int)$_GET['prova_id'] : null;

// Atualizar o título da prova
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['titulo'])) {
    $titulo = $_POST['titulo'];
    $sql = "UPDATE provas SET titulo = ? WHERE prova_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $titulo, $prova_id);
    if (!$stmt->execute()) {
        die("Erro ao atualizar o título da prova: " . $stmt->error);
    }
}

// Atualizar perguntas existentes ou adicionar novas
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['perguntas'])) {
    foreach ($_POST['perguntas'] as $id => $dados) {
        if (!isset($dados['id'])) continue; // Verifica se o ID da pergunta está definido
        
        if ($id > 0) {
            // Atualizar perguntas existentes
            $sql = "UPDATE perguntas SET pergunta = ?, opcao_a = ?, opcao_b = ?, opcao_c = ?, opcao_d = ?, resposta_correta = ? WHERE pergunta_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssssi", $dados['pergunta'], $dados['opcao_a'], $dados['opcao_b'], $dados['opcao_c'], $dados['opcao_d'], $dados['resposta_correta'], $id);
            if (!$stmt->execute()) {
                die("Erro ao atualizar a pergunta: " . $stmt->error);
            }
        } else {
            // Adicionar novas perguntas
            $sql = "INSERT INTO perguntas (prova_id, pergunta, opcao_a, opcao_b, opcao_c, opcao_d, resposta_correta) VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("issssss", $prova_id, $dados['pergunta'], $dados['opcao_a'], $dados['opcao_b'], $dados['opcao_c'], $dados['opcao_d'], $dados['resposta_correta']);
            if (!$stmt->execute()) {
                die("Erro ao adicionar a pergunta: " . $stmt->error);
            }
        }
    }

    // Armazenar mensagem de sucesso na sessão
    $_SESSION['mensagem_sucesso'] = "Sua edição foi salva.";
    // Redirecionar para a mesma página para exibir a mensagem
    header('Location: editar_prova.php?prova_id=' . $prova_id);
    exit();
}

// Buscar detalhes da prova
$sql = "SELECT titulo FROM provas WHERE prova_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $prova_id);
$stmt->execute();
$prova = $stmt->get_result()->fetch_assoc();

// Buscar perguntas da prova
$sql = "SELECT * FROM perguntas WHERE prova_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $prova_id);
$stmt->execute();
$perguntas = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$conn->close();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Prova</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <h1 class="mt-5">Editar Prova - <?= htmlspecialchars($prova['titulo']) ?></h1>

    <!-- Exibir mensagem de sucesso -->
    <?php if (isset($_SESSION['mensagem_sucesso'])): ?>
        <div class="alert alert-success" role="alert">
            <?= $_SESSION['mensagem_sucesso'] ?>
        </div>
        <?php unset($_SESSION['mensagem_sucesso']); // Limpar a mensagem após exibição ?>
    <?php endif; ?>

    <form method="post" class="mt-3">
        <div class="form-group">
            <label for="titulo">Título da Prova</label>
            <input type="text" class="form-control" id="titulo" name="titulo" value="<?= htmlspecialchars($prova['titulo']) ?>" required>
        </div>
        <?php foreach ($perguntas as $pergunta): ?>
        <div class="card mb-3">
            <div class="card-header">Editar Pergunta</div>
            <div class="card-body">
                <input type="hidden" name="perguntas[<?= $pergunta['pergunta_id'] ?>][id]" value="<?= $pergunta['pergunta_id'] ?>">
                <div class="form-group">
                    <label>Pergunta</label>
                    <input type="text" class="form-control" name="perguntas[<?= $pergunta['pergunta_id'] ?>][pergunta]" value="<?= htmlspecialchars($pergunta['pergunta']) ?>" required>
                </div>
                <div class="form-group">
                    <label>Opção A</label>
                    <input type="text" class="form-control" name="perguntas[<?= $pergunta['pergunta_id'] ?>][opcao_a]" value="<?= htmlspecialchars($pergunta['opcao_a']) ?>" required>
                </div>
                <div class="form-group">
                    <label>Opção B</label>
                    <input type="text" class="form-control" name="perguntas[<?= $pergunta['pergunta_id'] ?>][opcao_b]" value="<?= htmlspecialchars($pergunta['opcao_b']) ?>" required>
                </div>
                <div class="form-group">
                    <label>Opção C</label>
                    <input type="text" class="form-control" name="perguntas[<?= $pergunta['pergunta_id'] ?>][opcao_c]" value="<?= htmlspecialchars($pergunta['opcao_c']) ?>" required>
                </div>
                <div class="form-group">
                    <label>Opção D</label>
                    <input type="text" class="form-control" name="perguntas[<?= $pergunta['pergunta_id'] ?>][opcao_d]" value="<?= htmlspecialchars($pergunta['opcao_d']) ?>" required>
                </div>
                <div class="form-group">
                    <label>Resposta Correta</label>
                    <select class="form-control" name="perguntas[<?= $pergunta['pergunta_id'] ?>][resposta_correta]" required>
                        <option value="A" <?= $pergunta['resposta_correta'] == 'A' ? 'selected' : '' ?>>A</option>
                        <option value="B" <?= $pergunta['resposta_correta'] == 'B' ? 'selected' : '' ?>>B</option>
                        <option value="C" <?= $pergunta['resposta_correta'] == 'C' ? 'selected' : '' ?>>C</option>
                        <option value="D" <?= $pergunta['resposta_correta'] == 'D' ? 'selected' : '' ?>>D</option>
                    </select>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
        <button type="submit" class="btn btn-success">Salvar Alterações</button>
        <a href="listar_provas.php" class="btn btn-info mt-3">Voltar</a>
    </form>
</div>
</body>
</html>
