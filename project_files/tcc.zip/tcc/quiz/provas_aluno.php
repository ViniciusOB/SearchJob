<?php
include '../config.php'; // Inclua o arquivo de configuração para conectar ao banco de dados

// Verifique se a conexão foi estabelecida corretamente
if (!$conn) {
    die("Falha na conexão com o banco de dados: " . $conn->connect_error);
}

// Buscar provas disponíveis
$sql = "SELECT provas.prova_id, disciplinas.nome AS disciplina, provas.titulo 
        FROM provas 
        JOIN disciplinas ON provas.disciplina_id = disciplinas.disciplina_id";

// Execute a consulta
$result = $conn->query($sql);

// Verifique se a consulta foi bem-sucedida
if ($result === false) {
    die("Erro ao buscar provas: " . $conn->error);
}

// Armazene os resultados em um array
$provas = [];
while ($row = $result->fetch_assoc()) {
    $provas[] = $row;
}

// Fechar a conexão
$conn->close();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Realizar Provas</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="quiz.css" rel="stylesheet"> <!-- Inclua seu CSS personalizado -->
  

<style>
body {
    background-image: url('pexels-lum3n-44775-167682.jpg');
    background-size: cover;
    background-position: center;
    background-attachment: fixed;
    color: #fff;
}

</style>
</head>
<body>
<div class="container">
    <h1 class="mt-5 text-center">Selecione uma Prova para Realizar</h1>
    <div class="row mt-4">
        <?php foreach ($provas as $prova): ?>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <div>
                            <h5 class="card-title"><?= htmlspecialchars($prova['disciplina']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($prova['titulo']) ?></p>
                        </div>
                      <a href="realizar_prova.php?prova_id=<?= htmlspecialchars($prova['prova_id']) ?>" class="btn btn-primary">Realizar Prova</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <a href="inicial.php" class="btn btn-info mt-3">Voltar ao Menu Principal</a>
</div>
</body>
</html>
