<?php
// Inclua a configuração da conexão com o banco de dados
include 'config.php'; // Certifique-se de que o caminho está correto

// Inicie a sessão
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Verifique se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Verifique se a conexão com o banco de dados foi estabelecida
if (!$conn) {
    die("Falha na conexão com o banco de dados: " . mysqli_connect_error());
}

// Inicialize a variável $perfil
$perfil = null;

// Carrega o perfil atual do usuário usando mysqli
$query = $conn->prepare("SELECT * FROM perfis WHERE usuario_id = ?");
if ($query) {
    $query->bind_param("i", $user_id);
    $query->execute();
    $result = $query->get_result();
    $perfil = $result->fetch_assoc();
} else {
    echo "Erro ao preparar a consulta: " . $conn->error;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meu Perfil</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="CSS/perfil.css"> <!-- Certifique-se de que este caminho está correto -->
    <style>
       body {
    font-family: Arial, sans-serif;
    background-color: #000; /* Fundo preto */
    color: #fff;
    margin-top: 56px;
}

.navbar {
    background-color: #000; /* Cor escura para a navbar */
    padding: 10px 0;
    border-bottom: 1px solid #444;
}

.navbar .container {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.navbar-brand {
    font-size: 1.5rem;
    color: #d6a4d0; /* Roxo claro */
    text-decoration: none;
}

.navbar-brand:hover {
    color: #b39ddb; /* Tom mais escuro de roxo */
}

.navbar-nav {
    list-style: none;
    display: flex;
    gap: 15px;
}

.nav-item {
    margin: 0;
}

.nav-link {
    color: #d6a4d0; /* Roxo claro */
    text-decoration: none;
    font-size: 1rem;
    padding: 5px 10px;
    border-radius: 5px;
    transition: background-color 0.3s ease, color 0.3s ease;
}

.nav-link:hover {
    background-color: #5d3a6b; /* Tom mais escuro de roxo */
    color: #fff;
}

.container {
    max-width: 800px;
    padding: 20px;
    background-color: #333; /* Quadrado cinza escuro */
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    margin: 20px auto;
}

h2 {
    color: #d6a4d0; /* Roxo claro */
    margin-bottom: 20px;
}

img.rounded-circle {
    border: 3px solid #555; /* Borda cinza escuro */
    margin-bottom: 15px;
}

h3 {
    color: #d6a4d0; /* Roxo claro */
    margin-bottom: 10px;
}

p {
    margin: 10px 0;
}

strong {
    color: #fff;
}

.btn-primary {
    background-color: #d6a4d0; /* Roxo claro */
    border-color: #d6a4d0;
    color: #fff;
}

.btn-primary:hover {
    background-color: #5d3a6b; /* Tom mais escuro de roxo */
    border-color: #5d3a6b;
}

.btn-primary:focus, .btn-primary.focus {
    box-shadow: 0 0 0 0.2rem rgba(132, 54, 82, 0.5); /* Tom mais claro de roxo para foco */
}

.alert {
    background-color: #444; /* Cor de fundo escura para alertas */
    color: #fff;
    border-color: #555; /* Borda cinza escuro */
}

.alert-info {
    border-color: #5d3a6b; /* Tom de roxo escuro */
}

.alert-info .alert-link {
    color: #d6a4d0; /* Roxo claro */
}

    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="paralax.php">EstudeAqui</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a href="sobrenos.php" class="nav-link">Sobre nós</a></li>
                    <li class="nav-item"><a href="quiz/inicial.php" class="nav-link">Tarefas</a></li>
                    <li class="nav-item"><a href="agenda.php" class="nav-link">Agenda de Lives</a></li>
                    <li class="nav-item"><a href="paralax.php" class="nav-link">Home</a></li>

                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <h2>Meu Perfil</h2>

        <?php if ($perfil): ?>
            <div class="text-center">
                <?php if (!empty($perfil['foto_perfil'])): ?>
                    <img src="<?= htmlspecialchars($perfil['foto_perfil']) ?>" alt="Foto de Perfil" class="rounded-circle" width="150" height="150">
                <?php else: ?>
                    <img src="default-profile.png" alt="Foto de Perfil Padrão" class="rounded-circle" width="150" height="150">
                <?php endif; ?>
            </div>

            <h3 class="text-center"><?= htmlspecialchars($perfil['nome']) ?></h3>
            <p><strong>Idade:</strong> <?= htmlspecialchars($perfil['idade']) ?></p>
            <p><strong>Interesses:</strong> <?= htmlspecialchars($perfil['interesses']) ?></p>
            <p><strong>Matérias Favoritas:</strong> <?= htmlspecialchars($perfil['materias_favoritas']) ?></p>
            <p><strong>Descrição:</strong> <?= htmlspecialchars($perfil['descricao']) ?></p>

            <div class="text-center">
                <a href="editar_perfil.php" class="btn btn-primary">Editar Perfil</a>
            </div>
        <?php else: ?>
            <p>Perfil não encontrado.</p>
            <div class="text-center">
                <a href="criar_perfil.php" class="btn btn-primary btn-block">Criar meu perfil</a>
            </div>
        <?php endif; ?>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
// Feche a conexão
if (isset($query)) {
    $query->close();
}
$conn->close();
?>
