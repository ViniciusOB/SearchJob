<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="CSS/agendac.css">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="container">
            <a href="paralax.php" class="navbar-brand">EstudeAqui</a>
            <h1 class="text-center">Agenda</h1>
        </div>
    </nav>

    <!-- Estilos da Navbar -->
    <style>
        .navbar {
            background-color: #ffffff; /* Fundo branco */
            border-bottom: 1px solid #cccccc; /* Linha sutil na parte inferior */
            padding: 10px 0;
        }
        .navbar .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .navbar-brand {
            font-size: 1.5rem;
            color: #000; /* Azul */
            text-decoration: none;
        }
        .navbar-nav {
            list-style: none;
            display: flex;
            gap: 15px;
        }
        .nav-item {
            margin: 0;
        }
        .nav-link {
            color: #0000FF; /* Azul */
            text-decoration: none;
            font-size: 1rem;
            padding: 5px 10px;
            border-radius: 5px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }
        .nav-link:hover {
            background-color: #f0f0f0;
            color: #0056b3;
        }
    </style>

    <div class="container mt-4">
        <div id='calendar'></div>
    </div>

    <!-- Modal Visualizar -->
    <div class="modal fade" id="visualizarModal" tabindex="-1" aria-labelledby="visualizarModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="visualizarModalLabel">Visualizar o evento</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <dl class="row">
                        <dt class="col-sm-3">Materia:</dt>
                        <dd class="col-sm-9" id="visualizar_nome_materia"></dd>
                        <dt class="col-sm-3">Descrição:</dt>
                        <dd class="col-sm-9" id="visualizar_descricao"></dd>
                        <dt class="col-sm-3">Horario:</dt>
                        <dd class="col-sm-9" id="visualizar_horario"></dd>
                        <dt class="col-sm-3">Link da Live:</dt>
                        <dd class="col-sm-9" id="visualizar_link_live"></dd>
                    </dl>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Cadastrar -->
    <div class="modal fade" id="cadastrarModal" tabindex="-1" aria-labelledby="cadastrarModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="cadastrarModalLabel">Cadastrar o evento</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="POST" id="formCadEvento">
                        <div class="row mb-3">
                            <label for="cad_nome_materia" class="col-sm-2 col-form-label">Titulo</label>
                            <div class="col-sm-10">
                                <input type="text" name="cad_nome_materia" class="form-control" id="cad_nome_materia" placeholder="Titulo da live">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="cad_descricao" class="col-sm-2 col-form-label">Descrição</label>
                            <div class="col-sm-10">
                                <input type="text" name="cad_descricao" class="form-control" id="cad_descricao" placeholder="Descrição da live">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="cad_horario" class="col-sm-2 col-form-label">Horario</label>
                            <div class="col-sm-10">
                                <input type="datetime-local" name="cad_horario" class="form-control" id="cad_horario">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="cad_link_live" class="col-sm-2 col-form-label">Link da Live</label>
                            <div class="col-sm-10">
                                <input type="text" name="cad_link_live" class="form-control" id="cad_link_live" placeholder="Link da Live">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="cad_professor_id" class="col-sm-2 col-form-label">ID do Professor</label>
                            <div class="col-sm-10">
                                <input type="text" name="cad_professor_id" class="form-control" id="cad_professor_id" placeholder="ID do professor">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="cad_cor" class="col-sm-2 col-form-label">Cor</label>
                            <div class="col-sm-10">
                                <select name="cad_cor" class="form-control" id="cad_cor">
                                    <option value="">Selecione</option>
                                    <option value="#FF0000">Vermelho</option>
                                    <option value="#00FF00">Verde</option>
                                    <option value="#0000FF">Azul</option>
                                    <option value="#FFFF00">Amarelo</option>
                                    <option value="#800080">Roxo</option>
                                    <option value="#FFA500">Laranja</option>
                                    <option value="#00FFFF">Ciano</option>
                                    <option value="#FF00FF">Magenta</option>
                                    <option value="#808080">Cinza</option>
                                    <option value="#A52A2A">Marrom</option>
                                    <option value="#FFC0CB">Rosa</option>
                                </select>
                            </div>
                        </div>
                        <button type="submit" name="btnCadEvento" class="btn btn-success" id="btnCadEvento">Cadastrar</button>
                    </form>
                </div>
                <div class="modal-footer"></div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/index.global.min.js"></script>
    <script src="js/bootstrap5/index.global.min.js"></script>
    <script src="js/core/locales-all.global.min.js"></script>
    <script src="js/agen.js"></script>

    
<footer class="footer text-center py-3 mt-4">
    <p>&copy; 2024 EstudeAqui</p>
</footer>
</body>
</html>
