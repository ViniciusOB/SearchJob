<?php
$servername = "45.152.44.154";
$username = "u451416913_2024grupo07";
$password = "Grupo07@123";
$dbname = "u451416913_2024grupo07";

// Cria a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Inicia a sessão
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Verifica se é o formulário de login
    if (isset($_POST['email'], $_POST['password'])) {
        $email = $_POST['email'];
        $password = $_POST['password'];

        // Prepara a consulta SQL para evitar injeção SQL
        $stmt = $conn->prepare("SELECT usuario_id, senha FROM usuarios WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Busca o resultado da consulta
            $row = $result->fetch_assoc();

            // Verifica se a senha corresponde ao texto armazenado
            if ($password === $row['senha']) { // Comparação direta
                // Armazena o ID do usuário na sessão
                $_SESSION['user_id'] = $row['usuario_id']; // Correção aqui

                // Redireciona para a página inicial após login bem-sucedido
                header("Location: paralax.php");
                exit();
            } else {
                echo "Senha incorreta.";
            }
        } else {
            echo "Email não encontrado.";
        }

        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="CSS/login.css">
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <a href="#" class="navbar-brand">EstudeAqui</a>
            <ul class="navbar-nav">
                <li class="nav-item"><a href="paralax.php" class="nav-link">Home</a></li>
                <li class="nav-item"><a href="#" class="nav-link">Sobre nós</a></li>
                <li class="nav-item ciano"><a href="cadastro.php" class="nav-link">Cadastro</a></li>
            </ul>
        </div>
    </nav>

    <div class="page">
        <form method="POST" class="formLogin" action="login.php">
            <h1>Login</h1>
            <p>Digite os seus dados de acesso no campo abaixo.</p>
            <label for="email">E-mail</label>
            <input type="email" name="email" placeholder="Digite seu e-mail" autofocus="true" required />
            <label for="password">Senha</label>
            <input type="password" name="password" placeholder="Digite sua senha" required />
            <a href="recuperar_senha.php">Esqueci minha senha</a>
            <input type="submit" value="Acessar" class="btn" />
        </form>
    </div>

    
<footer class="footer text-center py-3 mt-4">
    <p>&copy; 2024 EstudeAqui</p>
</footer>
</body>
</html>
