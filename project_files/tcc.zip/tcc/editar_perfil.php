<?php
include 'config.php'; // Inclui a configuração de conexão com o banco de dados

// Inicia a sessão
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Verifica se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Processa o formulário quando enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $idade = $_POST['idade'];
    $interesses = $_POST['interesses'];
    $materias_favoritas = $_POST['materias_favoritas'];
    $descricao = $_POST['descricao'];

    // Inicializa o caminho da foto como nulo
    $foto_perfil = null;

    // Verifica se foi enviado um arquivo para a foto de perfil
    if (!empty($_FILES['foto_perfil']['name'])) {
        $target_dir = "profile_pics/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        $foto_perfil = $target_dir . basename($_FILES['foto_perfil']['name']);
        $imageFileType = strtolower(pathinfo($foto_perfil, PATHINFO_EXTENSION));

        // Verifica se o arquivo é uma imagem
        $check = getimagesize($_FILES['foto_perfil']['tmp_name']);
        if ($check !== false) {
            // Move o arquivo para o diretório de uploads
            if (move_uploaded_file($_FILES['foto_perfil']['tmp_name'], $foto_perfil)) {
                // Foto de perfil carregada com sucesso
            } else {
                $foto_perfil = null; // Se o upload falhar, não salva a imagem
            }
        } else {
            $foto_perfil = null; // Se não for uma imagem, não salva o caminho
        }
    }

    // Atualiza o perfil no banco de dados
    $query = $conn->prepare("UPDATE perfis SET nome = ?, idade = ?, interesses = ?, materias_favoritas = ?, descricao = ?, foto_perfil = COALESCE(?, foto_perfil) WHERE usuario_id = ?");
    $query->bind_param("sissssi", $nome, $idade, $interesses, $materias_favoritas, $descricao, $foto_perfil, $user_id);

    if ($query->execute()) {
        $_SESSION['message'] = "";
        header('Location: perfil.php'); // Redireciona para a página de perfil
        exit();
    } else {
        $_SESSION['message'] = "Erro ao atualizar o perfil: " . $query->error;
    }
}

// Carrega o perfil atual do usuário
$query = $conn->prepare("SELECT * FROM perfis WHERE usuario_id = ?");
$query->bind_param("i", $user_id);
$query->execute();
$result = $query->get_result();
$perfil = $result->fetch_assoc();

// Verifica se o perfil foi encontrado
if (!$perfil) {
    $_SESSION['message'] = "Perfil não encontrado. Certifique-se de que você tenha um perfil configurado.";
    header('Location: criar_perfil.php'); // Redireciona para a página de criação de perfil, se necessário
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Perfil</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #000; /* Fundo preto */
    color: #fff; /* Texto branco para contraste */
}

.navbar {
    background-color: #000; /* Roxo escuro para a barra de navegação */
}

.navbar-brand, .nav-link {
    color: #fff !important; /* Texto branco na barra de navegação */
}

.nav-link:hover {
    color: #a16a6a !important; /* Lilás suave para o hover */
}

.container {
    margin-top: 30px;
    background-color: #333; /* Fundo cinza escuro para o conteúdo */
    padding: 25px; /* Adiciona espaçamento interno */
    border-radius: 8px; /* Arredonda os cantos */
    max-width: 800px;
    padding: 20px;
}

.btn-primary {
    background-color: #d6a4d0; /* Lilás vibrante para os botões */
    border-color: #ab47bc; /* Borda lilás vibrante */
    color: #000 !important; 
}

.btn-primary:hover {
    background-color: #8e24aa; /* Roxo médio para o hover */
    border-color: #8e24aa;
}

.form-control {
    border: 2px solid #d6a4d0; /* Lilás vibrante para os campos de formulário */
    border-radius: 5px;
}

.form-control:focus {
    border-color: #8e24aa; /* Roxo médio no foco */
    box-shadow: 0 0 5px #8e24aa; /* Sombra lilás para foco */
}

.img-thumbnail {
    border-radius: 50%;
    border: 2px solid #ab47bc; /* Lilás vibrante para borda das imagens */
}

.custom-file-upload {
    border: 1px solid #d6a4d0; /* Lilás vibrante para o botão de upload */
    display: inline-block;
    padding: 6px 12px;
    cursor: pointer;
    border-radius: 5px;
    background-color: #d6a4d0; /* Lilás vibrante */
    color: white;
    color: #000 !important; 
        color: #000 !important; 


}

.custom-file-upload:hover {
    background-color: #8e24aa; /* Roxo médio para o hover */
}

.alert {
    padding: 10px;
    font-size: 0.9rem;
    border-radius: 5px;
    background-color: #d4edda; /* Verde claro para o fundo dos alertas */
    color: #155724; /* Verde escuro para o texto */
    border-color: #c3e6cb; /* Verde claro para a borda */
}


    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="paralax.php">EstudeAqui</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item"><a href="sobrenos.php" class="nav-link">Sobre nós</a></li>
                <li class="nav-item"><a href="quiz/inicial.php" class="nav-link">Tarefas</a></li>
                <li class="nav-item"><a href="agenda.php" class="nav-link">Ao vivo</a></li>
                <li class="nav-item"><a href="perfil.php" class="nav-link">Voltar ao Perfil</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <h2>Editar Perfil</h2>

    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-info">
            <?= htmlspecialchars($_SESSION['message']) ?>
            <?php unset($_SESSION['message']); ?>
        </div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <div class="form-group">
         <label for="foto_perfil">Foto de Perfil:</label>
        <center>
            <?php if ($perfil['foto_perfil']): ?>
              <img src="<?= htmlspecialchars($perfil['foto_perfil']) ?>" alt="Foto de Perfil" class="img-thumbnail mt-2" width="150"></center> 
            <?php else: ?>
                <p class="mt-2">Nenhuma foto de perfil escolhida.</p>
            <?php endif; ?>
            <label class="custom-file-upload">
                <input type="file" name="foto_perfil" id="foto_perfil" style="display: none;">
                Escolher arquivo
            </label>
        </div>

        <div class="form-group">
            <label for="nome">Nome:</label>
            <input type="text" name="nome" class="form-control" value="<?= htmlspecialchars($perfil['nome']) ?>" required>
        </div>
        <div class="form-group">
            <label for="idade">Idade:</label>
            <input type="number" name="idade" class="form-control" value="<?= htmlspecialchars($perfil['idade']) ?>" required>
        </div>
        <div class="form-group">
            <label for="interesses">Interesses:</label>
            <input type="text" name="interesses" class="form-control" value="<?= htmlspecialchars($perfil['interesses']) ?>">
        </div>
        <div class="form-group">
            <label for="materias_favoritas">Matérias Favoritas:</label>
            <input type="text" name="materias_favoritas" class="form-control" value="<?= htmlspecialchars($perfil['materias_favoritas']) ?>">
        </div>
        <div class="form-group">
            <label for="descricao">Descrição:</label>
            <textarea name="descricao" class="form-control"><?= htmlspecialchars($perfil['descricao']) ?></textarea>
        </div>
        
        <button type="submit" class="btn btn-primary">Salvar Alterações</button>
    </form>
</div>

<footer class="footer text-center py-3 mt-4">
    <p>&copy; 2024 EstudeAqui</p>
</footer>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.7/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
