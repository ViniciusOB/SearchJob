<?php
include 'config.php'; // Inclui a configuração de conexão com o banco de dados

// Inicia a sessão
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Verifica se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Atualiza ou cria o perfil
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $idade = $_POST['idade'];
    $interesses = $_POST['interesses'];
    $materias_favoritas = $_POST['materias_favoritas'];
    $descricao = $_POST['descricao'];

    // Inicializa a variável para a foto de perfil
    $foto_perfil = null;

    // Upload da foto
    if (!empty($_FILES['foto_perfil']['name'])) {
        $upload_dir = 'profile_pics/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        $foto_perfil = $upload_dir . basename($_FILES['foto_perfil']['name']);
        if (move_uploaded_file($_FILES['foto_perfil']['tmp_name'], $foto_perfil) === false) {
            $error = 'Erro ao fazer upload da foto de perfil.';
        }
    }

    // Atualiza ou insere o perfil no banco de dados
    if ($foto_perfil) {
        $query = $conn->prepare("INSERT INTO perfis (usuario_id, nome, idade, interesses, materias_favoritas, descricao, foto_perfil)
                                 VALUES (?, ?, ?, ?, ?, ?, ?)
                                 ON DUPLICATE KEY UPDATE nome = VALUES(nome), idade = VALUES(idade),
                                 interesses = VALUES(interesses), materias_favoritas = VALUES(materias_favoritas),
                                 descricao = VALUES(descricao), foto_perfil = VALUES(foto_perfil)");
        $query->bind_param("isissss", $user_id, $nome, $idade, $interesses, $materias_favoritas, $descricao, $foto_perfil);
    } else {
        $query = $conn->prepare("INSERT INTO perfis (usuario_id, nome, idade, interesses, materias_favoritas, descricao)
                                 VALUES (?, ?, ?, ?, ?, ?)
                                 ON DUPLICATE KEY UPDATE nome = VALUES(nome), idade = VALUES(idade),
                                 interesses = VALUES(interesses), materias_favoritas = VALUES(materias_favoritas),
                                 descricao = VALUES(descricao)");
        $query->bind_param("isisss", $user_id, $nome, $idade, $interesses, $materias_favoritas, $descricao);
    }

    if ($query->execute()) {
        $_SESSION['message'] = "Perfil atualizado com sucesso!";
        header('Location: perfil.php'); // Redireciona para a página de perfil
        exit();
    } else {
        $error = 'Erro ao atualizar o perfil: ' . $query->error;
    }

    // Fecha a conexão e o statement
    $query->close();
    $conn->close();
}

// Carrega o perfil atual do usuário se existir
$query = $conn->prepare("SELECT * FROM perfis WHERE usuario_id = ?");
$query->bind_param("i", $user_id);
$query->execute();
$result = $query->get_result();
$perfil = $result->fetch_assoc();

// Fecha a conexão e o statement
$query->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Criar Perfil</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
/* Estilização Geral */
body {
    font-family: Arial, sans-serif;
    background-color: #000; /* Fundo preto */
    color: #fff; /* Texto branco para contraste */
    margin: 0;
    padding: 0;
}

/* Navbar */
.navbar {
    background-color: #1a1a1a; /* Fundo cinza escuro para a barra de navegação */
    border-bottom: 1px solid #333; /* Linha inferior sutil */
}

.navbar-brand, .nav-link {
    color: #d6a4d0 !important; /* Lilás suave para a barra de navegação */
}

.navbar-brand:hover, .nav-link:hover {
    color: #ab47bc !important; /* Roxo médio para o hover */
}

.navbar-toggler-icon {
    background-color: #d6a4d0; /* Lilás suave para o ícone do menu (hamburger) */
}

/* Container Principal */
.container {
    margin-top: 30px;
    background-color: #333; /* Fundo cinza escuro para o conteúdo */
    padding: 25px; /* Adiciona espaçamento interno */
    border-radius: 8px; /* Arredonda os cantos */
    max-width: 800px;
    margin: 30px auto; /* Centraliza o container */
}

/* Botões */
.btn-primary {
    background-color: #d6a4d0; /* Lilás vibrante para os botões */
    border-color: #ab47bc; /* Borda lilás vibrante */
    color: #000 !important; /* Texto preto para contraste */
}

.btn-primary:hover {
    background-color: #ab47bc; /* Roxo médio para o hover */
    border-color: #ab47bc;
}

/* Campos de Formulário */
.form-control {
    border: 2px solid #d6a4d0; /* Lilás vibrante para os campos de formulário */
    border-radius: 5px;
    background-color: #444; /* Fundo cinza escuro para os campos de formulário */
    color: #fff; /* Texto branco nos campos de formulário */
    box-shadow: none; /* Remove a sombra dos campos de formulário */
}

.form-control:focus {
    border-color: #ab47bc; /* Roxo médio no foco */
    box-shadow: 0 0 0 0 #ab47bc; /* Remove a sombra lilás ao redor */
}

/* Imagens */
.img-thumbnail {
    border-radius: 50%;
    border: 2px solid #d6a4d0; /* Lilás vibrante para borda das imagens */
}

/* Botão de Upload de Arquivo */
.custom-file-upload {
    border: 1px solid #d6a4d0; /* Lilás vibrante para o botão de upload */
    display: inline-block;
    padding: 6px 12px;
    cursor: pointer;
    border-radius: 5px;
    background-color: #d6a4d0; /* Lilás vibrante */
    color: #000 !important; /* Texto preto para contraste */
}

.custom-file-upload:hover {
    background-color: #ab47bc; /* Roxo médio para o hover */
}

/* Alertas */
.alert {
    padding: 10px;
    font-size: 0.9rem;
    border-radius: 5px;
    background-color: #444; /* Fundo cinza escuro para alertas */
    color: #fff; /* Texto branco */
    border-color: #555; /* Borda cinza escuro */
}

.card-body {
    -ms-flex: 1 1 auto;
    flex: 1 1 auto;
    min-height: 1px;
    padding: 1.25rem;
    background-color: #333; }

    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="paralax.php">EstudeAqui</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a href="sobrenos.php" class="nav-link">Sobre nós</a></li>
                    <li class="nav-item"><a href="quiz/inicial.php" class="nav-link">Tarefas</a></li>
                    <li class="nav-item"><a href="agenda.php" class="nav-link">Ao vivo</a></li>
                </ul>
            </div>
        </div>
    </nav>
<div class="container mt-4">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="card">
                <div class="card-body text-center">
                    <?php if ($perfil && isset($perfil['foto_perfil'])): ?>
                        <img src="<?php echo htmlspecialchars($perfil['foto_perfil']); ?>" alt="Foto de perfil" class="img-thumbnail mb-3" style="width: 150px; height: 150px;">
                    <?php else: ?>
                        <img src="default-profile.png" alt="Foto de perfil padrão" class="img-thumbnail mb-3" style="width: 150px; height: 150px;">
                    <?php endif; ?>
                    <h2 class="card-title">Criar Perfil</h2>
                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                    <?php endif; ?>
                    <form action="criar_perfil.php" method="POST" enctype="multipart/form-data" class="mb-3">
                        <div class="form-group">
                            <label for="nome">Nome:</label>
                            <input type="text" id="nome" name="nome" class="form-control" value="<?= htmlspecialchars($perfil['nome'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="idade">Idade:</label>
                            <input type="number" id="idade" name="idade" class="form-control" value="<?= htmlspecialchars($perfil['idade'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="interesses">Interesses:</label>
                            <input type="text" id="interesses" name="interesses" class="form-control" value="<?= htmlspecialchars($perfil['interesses'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label for="materias_favoritas">Matérias Favoritas:</label>
                            <input type="text" id="materias_favoritas" name="materias_favoritas" class="form-control" value="<?= htmlspecialchars($perfil['materias_favoritas'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label for="descricao">Descrição:</label>
                            <textarea id="descricao" name="descricao" class="form-control"><?= htmlspecialchars($perfil['descricao'] ?? '') ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="foto_perfil">Foto de Perfil:</label>
                            <input type="file" id="foto_perfil" name="foto_perfil" class="form-control-file">
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Salvar Alterações</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<footer class="footer text-center py-3 mt-4">
    <p>&copy; 2024 estudeaqui</p>
</footer>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
