<!DOCTYPE html>
<html lang="PT-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&family=Marck+Script&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href='CSS/home.css' rel='stylesheet'>
    <title>EstudeAqui - Plataforma de Aprendizado</title>
</head>
<body>

    <header class="header">
        <a href="#" class="logo">EstudeAqui</a>
        <nav class="navbar">
            <a href="cadastro.php">cadastro</a>
            <a href="login.php">login</a>
            <a href="#assinatura.php" class="cta-button">Assine Agora</a>
        </nav>
    </header>

    <section class="hero">
        <div class="hero-overlay"></div>
        <video class="hero-video" src="path/to/your/video.mp4" autoplay muted loop></video>
        <div class="hero-content">
            <h1>Bem-vindo ao EstudeAqui</h1>
            <p>Transforme seu aprendizado com cursos personalizados e suporte dedicado.</p>
            <a href="#planos" class="cta-button">Veja Nossos Planos</a>
        </div>
    </section>

    <section id="sobre" class="info-section">
        <div class="container">
            <h2>Sobre Nós</h2>
            <p>Descubra como nossa plataforma pode ajudar você a alcançar seus objetivos de aprendizado com ferramentas e suporte de qualidade. Nossa missão é fornecer a melhor experiência de aprendizado possível, com recursos que se adaptam às suas necessidades individuais.</p>
        </div>
    </section>

    <section id="funcionalidades" class="info-section">
        <div class="container">
            <h2>Funcionalidades</h2>
            <div class="features">
                <div class="feature">
                    <i class='bx bx-bulb'></i>
                    <h3>Aprendizado Personalizado</h3>
                    <p>Adaptamos o conteúdo para se adequar ao seu ritmo e estilo de aprendizado.</p>
                </div>
                <div class="feature">
                    <i class='bx bx-support'></i>
                    <h3>Suporte ao Vivo</h3>
                    <p>Receba assistência imediata com nossa equipe de suporte ao vivo.</p>
                </div>
                <div class="feature">
                    <i class='bx bx-certificate'></i>
                    <h3>Certificações</h3>
                    <p>Ganhe certificados ao concluir cursos e conquiste novos marcos.</p>
                </div>
            </div>
        </div>
    </section>

    <section id="planos" class="info-section">
        <div class="container">
            <h2>Planos e Preços</h2>
            <div class="pricing">
                <div class="pricing-plan">
                    <h3>Plano Básico</h3>
                    <p class="price">R$29/mês</p>
                    <ul>
                        <li>Acesso a todos os cursos básicos</li>
                        <li>Suporte por e-mail</li>
                    </ul>
                    <a href="#contato" class="cta-button">Assinar</a>
                </div>
                <div class="pricing-plan featured">
                    <h3>Plano Premium</h3>
                    <p class="price">R$59/mês</p>
                    <ul>
                        <li>Acesso a todos os cursos</li>
                        <li>Suporte prioritário</li>
                        <li>Live sessions exclusivas</li>
                    </ul>
                    <a href="#contato" class="cta-button">Assinar</a>
                </div>
                <div class="pricing-plan">
                    <h3>Plano Empresarial</h3>
                    <p class="price">R$99/mês</p>
                    <ul>
                        <li>Acesso ilimitado a cursos</li>
                        <li>Suporte dedicado</li>
                        <li>Relatórios detalhados</li>
                    </ul>
                    <a href="#contato" class="cta-button">Assinar</a>
                </div>
            </div>
        </div>
    </section>

    <section id="faq" class="info-section">
        <div class="container">
            <h2>Perguntas Frequentes</h2>
            <div class="faq-item">
                <h3>Como posso assinar um plano?</h3>
                <p>Você pode escolher um plano na seção "Planos e Preços" e clicar em "Assinar". Siga as instruções para concluir a assinatura.</p>
            </div>
            <div class="faq-item">
                <h3>Posso cancelar minha assinatura?</h3>
                <p>Sim, você pode cancelar sua assinatura a qualquer momento na sua conta de usuário.</p>
            </div>
            <div class="faq-item">
                <h3>Quais formas de pagamento são aceitas?</h3>
                <p>Aceitamos cartões de crédito, débito e pagamentos via PayPal.</p>
            </div>
        </div>
    </section>

</body>
</html>
