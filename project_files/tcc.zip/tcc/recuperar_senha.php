<?php
$servername = "45.152.44.154";
$username = "u451416913_2024grupo07";
$password = "Grupo07@123";
$dbname = "u451416913_2024grupo07";


// Cria a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $nova_senha = $_POST['nova_senha'];

    // Verifica se o email existe no banco de dados
    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Atualiza a senha no banco de dados
        $stmt_update = $conn->prepare("UPDATE usuarios SET senha = ? WHERE email = ?");
        $stmt_update->bind_param("ss", $nova_senha, $email);
        if ($stmt_update->execute()) {
            // Redireciona para a página de login após a atualização da senha
            header("Location: login.php");
            exit;
        } else {
            echo "Erro ao atualizar a senha: " . $conn->error;
        }
        $stmt_update->close();
    } else {
        echo "Email não encontrado.";
    }

    $stmt->close();
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Senha</title>
    <link rel="stylesheet" href="CSS/style.css">
</head>
<body>
<nav class="navbar">
        <div class="container">
            <a href="#" class="navbar-brand">EstudeAqui</a>
            <ul class="navbar-nav">
             <li class="nav-item ciano"><a href="cadastro.php" class="nav-link">Cadastro</a></li>
                <li class="nav-item ciano"><a href="login.php" class="nav-link">Login</a></li>
            </ul>
        </div>
    </nav>


    <div class="page">
        <form method="POST" class="formRecuperarSenha" action="">
            <h1>Recuperar Senha</h1>
            <p>Digite o seu email e a nova senha abaixo.</p>
            <label for="email">E-mail</label>
            <input type="email" name="email" placeholder="Digite seu e-mail" required />
            <label for="nova_senha">Nova Senha</label>
            <input type="password" name="nova_senha" placeholder="Digite sua nova senha" required />
            <input type="submit" value="Atualizar Senha" class="btn" />
        </form>
    </div>
</body>
</html>
