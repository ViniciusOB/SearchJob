<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/paralax.css">
    <title>EstudeAqui</title>
</head>
<body>
    
<nav class="navbar">
    <div class="container">
        <a href="home.php" class="navbar-brand">EstudeAqui</a>
        <ul class="navbar-nav">
            <li class="nav-item"><a href="perfil.php" class="nav-link">Perfil</a></li>
            <li class="nav-item"><a href="#" class="nav-link">Tarefas</a></li>
            <li class="nav-item"><a href="agenda.php" class="nav-link">Agenda de Lives</a></li>
          
        </ul>
    </div>
</nav>

<div class="wrapper">
    <main>
        <!-- Seção de Parallax -->
        <section class="module parallax parallax-1">
            <div class="parallax-content">
                <h2>Bem-vindo ao EstudeAqui</h2>
            </div>
        </section>

        <!-- Seção de Conteúdo -->
        <section class="module content">
            <div class="container">
                <p>Uma das características mais destacadas do EstudeAqui são os vídeos exclusivos. Criados por especialistas em diversas áreas, esses vídeos cobrem uma ampla gama de tópicos, desde ciências exatas até humanidades. Cada vídeo é cuidadosamente elaborado para garantir que você obtenha uma compreensão profunda e clara do assunto estudado. Além disso, nossos vídeos são acompanhados de materiais de apoio que facilitam a revisão e o aprofundamento dos conteúdos.</p>
            </div>
        </section>

        <!-- Outra Seção de Parallax -->
        <section class="module parallax parallax-2">
            <div class="parallax-content">
                <h2>Vídeo aulas com links exclusivos</h2>
            </div>
        </section>

        <!-- Outra Seção de Conteúdo -->
        <section class="module content">
            <div class="container">
                <p>Outra característica importante são as vídeo aulas com links exclusivos. Cada aula é projetada para fornecer um conteúdo rico e envolvente, com links que ajudam a acessar materiais suplementares e recursos adicionais.</p>
            </div>
        </section>

        <!-- Mais uma Seção de Parallax -->
        <section class="module parallax parallax-3">
            <div class="parallax-content">
                <h2>Quizes para aprimorar seu aprendizado</h2>
            </div>
        </section>

        <!-- Seção Final de Conteúdo -->
        <section class="module content">
            <div class="container">
                <p>Email: EstudeAqui@gmail.com</p>
                <p>Telefone: (19) 9935-4672</p>
            </div>
        </section>
    </main>
</div>

<footer class="footer text-center py-3 mt-4">
    <p>&copy; 2024 EstudeAqui</p>
</footer>

</body>
</html>
