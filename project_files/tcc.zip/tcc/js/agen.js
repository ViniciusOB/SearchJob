document.addEventListener('DOMContentLoaded', function () {

    // Seleciona o elemento do calendário
    var calendarEl = document.getElementById('calendar');

    // Inicializa os modais para cadastro e visualização
    const cadastrarModal = new bootstrap.Modal(document.getElementById("cadastrarModal"));
    const visualizarModal = new bootstrap.Modal(document.getElementById("visualizarModal"));

    // Seleciona os elementos de mensagem
    const msgViewEvento = document.getElementById('msgViewEvento');
    const msgCadEvento = document.getElementById('msgCadEvento');
    const msgEditEvento = document.getElementById('msgEditEvento');
    const msg = document.getElementById('msg');

    // Seleciona os botões de ação
    const btnCadEvento = document.getElementById("btnCadEvento");
    const btnEditEvento = document.getElementById("btnEditEvento");
    const btnApagarEvento = document.getElementById("btnApagarEvento");

    // Cria a instância do calendário
    var calendar = new FullCalendar.Calendar(calendarEl, {
        themeSystem: 'bootstrap5',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        locale: 'pt-br',
        navLinks: true,
        selectable: true,
        selectMirror: true,
        editable: true,
        dayMaxEvents: true,
        events: 'listar_evento.php',
        eventClick: function (info) {
            // Preenche os detalhes do evento na modal de visualização
            document.getElementById("visualizar_nome_materia").innerText = info.event.title;
            document.getElementById("visualizar_descricao").innerText = info.event.extendedProps.descricao || '';
            document.getElementById("visualizar_link_live").innerText = info.event.extendedProps.link_live || '';
            document.getElementById("visualizar_horario").innerText = info.event.start.toLocaleString();

            // Preenche o formulário de edição com os dados do evento
            document.getElementById("edit_id").value = info.event.id;
            document.getElementById("edit_nome_materia").value = info.event.title;
            document.getElementById("edit_descricao").value = info.event.extendedProps.descricao || '';
            document.getElementById("edit_link_live").value = info.event.extendedProps.link_live || '';
            document.getElementById("edit_horario").value = converterData(info.event.start);
            document.getElementById("edit_cor").value = info.event.extendedProps.cor || '';

            visualizarModal.show();
        },
        select: function (info) {
            // Preenche o formulário de cadastro com a data selecionada
            document.getElementById("cad_horario").value = converterData(info.start);
            cadastrarModal.show();
        }
    });

    // Renderiza o calendário
    calendar.render();

    // Função para converter a data para o formato ISO 8601
    function converterData(data) {
        const dataObj = new Date(data);
        const ano = dataObj.getFullYear();
        const mes = String(dataObj.getMonth() + 1).padStart(2, '0');
        const dia = String(dataObj.getDate()).padStart(2, '0');
        const hora = String(dataObj.getHours()).padStart(2, '0');
        const minuto = String(dataObj.getMinutes()).padStart(2, '0');
        return `${ano}-${mes}-${dia}T${hora}:${minuto}`;
    }

    // Manipula o formulário de cadastro de evento
    const formCadEvento = document.getElementById("formCadEvento");
    if (formCadEvento) {
        formCadEvento.addEventListener("submit", async (e) => {
            e.preventDefault();
            btnCadEvento.innerText = "Salvando...";
            const dadosForm = new FormData(e.target);
            const response = await fetch("cadastrar_evento.php", {
                method: "POST",
                body: dadosForm
            });

            const data = await response.json();

            if (!data.status) {
                msgCadEvento.innerHTML = `<div class="alert alert-danger" role="alert">${data.msg}</div>`;
            } else {
                msgCadEvento.innerHTML = "";
                formCadEvento.reset();
                calendar.addEvent({
                    id: data.id,
                    title: dadosForm.get('cad_nome_materia'),
                    start: dadosForm.get('cad_horario'),
                    extendedProps: {
                        descricao: dadosForm.get('cad_descricao'),
                        link_live: dadosForm.get('cad_link_live'),
                        cor: dadosForm.get('cad_cor')
                    }
                });
                msg.innerHTML = `<div class="alert alert-success" role="alert">${data.msg}</div>`;
                removerMsg();
                cadastrarModal.hide();
            }

            btnCadEvento.innerText = "Cadastrar";
        });
    }

    // Manipula o formulário de edição de evento
    const formEditEvento = document.getElementById("formEditEvento");
    if (formEditEvento) {
        formEditEvento.addEventListener("submit", async (e) => {
            e.preventDefault();
            btnEditEvento.innerText = "Salvando...";
            const dadosForm = new FormData(e.target);
            const response = await fetch("editar_evento.php", {
                method: "POST",
                body: dadosForm
            });

            const data = await response.json();

            if (!data.status) {
                msgEditEvento.innerHTML = `<div class="alert alert-danger" role="alert">${data.msg}</div>`;
            } else {
                msgEditEvento.innerHTML = "";
                formEditEvento.reset();
                const eventoExiste = calendar.getEventById(data.id);
                if (eventoExiste) {
                    eventoExiste.setProp('title', dadosForm.get('edit_nome_materia'));
                    eventoExiste.setExtendedProp('descricao', dadosForm.get('edit_descricao'));
                    eventoExiste.setExtendedProp('link_live', dadosForm.get('edit_link_live'));
                    eventoExiste.setExtendedProp('cor', dadosForm.get('edit_cor'));
                    eventoExiste.setStart(dadosForm.get('edit_horario'));
                }
                msg.innerHTML = `<div class="alert alert-success" role="alert">${data.msg}</div>`;
                removerMsg();
                visualizarModal.hide();
            }

            btnEditEvento.innerText = "Salvar";
        });
    }

    // Manipula a exclusão de evento
    if (btnApagarEvento) {
        btnApagarEvento.addEventListener("click", async () => {
            const confirmacao = window.confirm("Tem certeza de que deseja apagar este evento?");
            if (confirmacao) {
                const idEvento = document.getElementById("visualizar_id").innerText;
                const response = await fetch(`apagar_evento.php?id=${idEvento}`);
                const data = await response.json();

                if (!data.status) {
                    msgViewEvento.innerHTML = `<div class="alert alert-danger" role="alert">${data.msg}</div>`;
                } else {
                    msgViewEvento.innerHTML = "";
                    calendar.getEventById(idEvento)?.remove();
                    msg.innerHTML = `<div class="alert alert-success" role="alert">${data.msg}</div>`;
                    removerMsg();
                    visualizarModal.hide();
                }
            }
        });
    }

    // Função para remover mensagens após 3 segundos
    function removerMsg() {
        setTimeout(() => {
            msg.innerHTML = "";
        }, 3000);
    }
});
