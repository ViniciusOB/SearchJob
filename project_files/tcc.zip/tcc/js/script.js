// script.js

const paymentForm = document.getElementById('payment-form');
const submitPaymentButton = document.getElementById('submit-payment');

paymentForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const cardNumber = document.getElementById('card-number').value;
    const expirationDate = document.getElementById('expiration-date').value;
    const securityCode = document.getElementById('security-code').value;
    const amount = document.getElementById('amount').value;

    // Validate payment information
    if (!cardNumber || !expirationDate || !securityCode || !amount) {
        alert('Please fill out all fields.');
        return;
    }

    // Process payment (this is where you would integrate with a payment gateway)
    console.log('Payment processed successfully!');
    alert('Payment processed successfully!');
});

submitPaymentButton.addEventListener('click', () => {
    paymentForm.submit();
});