document.addEventListener('DOMContentLoaded', function () {
  // Configuração dos gráficos
  var ctx1 = document.getElementById('usersChart').getContext('2d');
  var ctx2 = document.getElementById('revenueChart').getContext('2d');

  var usersChart = new Chart(ctx1, {
      type: 'bar',
      data: {
          labels: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho'],
          datasets: [{
              label: 'Novos Usuários',
              data: [30, 40, 35, 50, 60, 70],
              backgroundColor: 'rgba(215, 168, 255, 0.3)', // Roxo neon
              borderColor: 'rgba(215, 168, 255, 1)', // Roxo neon
              borderWidth: 1
          }]
      },
      options: {
          responsive: true,
          scales: {
              y: {
                  beginAtZero: true,
                  grid: {
                      color: '#2e2e2e' // Preto mais claro
                  }
              },
              x: {
                  grid: {
                      color: '#2e2e2e' // Preto mais claro
                  }
              }
          },
          plugins: {
              legend: {
                  labels: {
                      color: '#ffffff'
                  }
              }
          }
      }
  });

  var revenueChart = new Chart(ctx2, {
      type: 'line',
      data: {
          labels: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho'],
          datasets: [{
              label: 'Receita',
              data: [5000, 7000, 6000, 8000, 9000, 10000],
              backgroundColor: 'rgba(215, 168, 255, 0.2)', // Roxo neon com opacidade
              borderColor: '#d7a8ff', // Roxo neon
              borderWidth: 2,
              fill: true
          }]
      },
      options: {
          responsive: true,
          scales: {
              y: {
                  beginAtZero: true,
                  grid: {
                      color: '#2e2e2e' // Preto mais claro
                  }
              },
              x: {
                  grid: {
                      color: '#2e2e2e' // Preto mais claro
                  }
              }
          },
          plugins: {
              legend: {
                  labels: {
                      color: '#ffffff'
                  }
              }
          }
      }
  });

  // Navegação suave
  const sections = document.querySelectorAll('section');
  const navLinks = document.querySelectorAll('header nav a');

  navLinks.forEach((link) => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const sectionId = link.getAttribute('href');
      const section = document.querySelector(sectionId);
      section.scrollIntoView({ behavior: 'smooth' });
    });
  });

  // Populando listas
  // Usuários
  const userList = document.querySelector('#users table tbody');
  for (let i = 0; i < 10; i++) {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${i + 1}</td>
      <td>Usuário ${i + 1}</td>
      <td>usuario${i + 1}@exemplo.com</td>
      <td>Aluno</td>
      <td><button>Editar</button> <button>Excluir</button></td>
    `;
    userList.appendChild(row);
  }

  // Professores
  const teacherList = document.querySelector('#teachers table tbody');
  for (let i = 0; i < 5; i++) {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${i + 1}</td>
      <td>Professor ${i + 1}</td>
      <td>professor${i + 1}@exemplo.com</td>
      <td>Aprovado</td>a
      <td><button>Editar</button> <button>Excluir</button></td>
    `;
    teacherList.appendChild(row);
  }

  // Aulas ao vivo
  const liveClassList = document.querySelector('#live-classes table tbody');
  for (let i = 0; i < 5; i++) {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${i + 1}</td>
      <td>Aula ao Vivo ${i + 1}</td>
      <td>2023-02-20 14:00</td>
      <td><button>Editar</button> <button>Excluir</button></td>
    `;
    liveClassList.appendChild(row);
  }

  // Aulas gravadas
  const recordedClassList = document.querySelector('#recorded-classes table tbody');
  for (let i = 0; i < 10; i++) {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${i + 1}</td>
      <td>Aula Gravada ${i + 1}</td>
      <td>2023-02-15</td>
      <td><button>Editar</button> <button>Excluir</button></td>
    `;
    recordedClassList.appendChild(row);
  }
});
