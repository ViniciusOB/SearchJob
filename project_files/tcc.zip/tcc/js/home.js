// Add event listener to the "Get Started" button
document.querySelector('.hero button').addEventListener('click', () => {
    // Redirect to the sign up page
    window.location.href = 'signup.html';
  });
  
  // Add event listener to the "Sign Up" button
  document.querySelector('.call-to-action button').addEventListener('click', () => {
    // Redirect to the sign up page
    window.location.href = 'signup.html';
  });
  
  // Add event listener to the navigation menu items
  document.querySelectorAll('header nav ul li a').forEach((link) => {
    link.addEventListener('click', (e) => {
      // Prevent default link behavior
      e.preventDefault();
      // Get the href attribute of the link
      const href = link.getAttribute('href');
      // Redirect to the corresponding page
      window.location.href = href;
    });
  });
  
  // Add event listener to the testimonial cards
  document.querySelectorAll('.testimonial-card').forEach((card) => {
    card.addEventListener('mouseover', () => {
      // Add a CSS class to the card to change its background color
      card.classList.add('hover');
    });
    card.addEventListener('mouseout', () => {
      // Remove the CSS class from the card
      card.classList.remove('hover');
    });
  });