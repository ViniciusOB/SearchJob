﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace loja
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btn_inserir_Click(object sender, EventArgs e)
        {
            // Pega o texto digitado na área do "txtFirstName" e armazena na variável "firstName"
            string Name = txtnome.Text;
            // Pega o texto digitado na área do "txtLastName" e armazena na variável "lastName"
            string ID = txtcodigo.Text;

            string Quantidade = txtquantidade.Text;

            string Preco = txtpreco.Text;

            string Descricao = txtdescricao.Text;

            string Complemento = txtcomplemento.Text;

            // Verificase os campos 'firsteName' e 'lastName' não estão vazios
            if (!string.IsNullOrEmpty(Name) && !string.IsNullOrEmpty(ID) && !string.IsNullOrEmpty(Quantidade) && !string.IsNullOrEmpty(Preco) && !string.IsNullOrEmpty(Descricao) && !string.IsNullOrEmpty(Complemento))
            {
                // Se os campos não estão vazios, cria um novo objeto da classe 'Person' com nome e o sobrenome
                add_produto produto = new add_produto(Name, ID, Quantidade, Preco, Descricao, Complemento);

                lstnames.Items.Add(produto);

                txtnome.Clear();
                txtcodigo.Clear();
                txtquantidade.Clear();
                txtpreco.Clear();
                txtdescricao.Clear();
                txtcomplemento.Clear();
            }
            else
            {
                MessageBox.Show("Por favor, preencha todos os campos", "Erro",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
