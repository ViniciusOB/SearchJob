﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace loja
{
    internal class add_produto
    {
        public string name { get; set; }
        public string iD { get; set; }
        public string quantidade { get; set; }
        public string preco { get; set; }
        public string descricao { get; set; }
        public string complemento { get; set; }


        public add_produto(string Name, string ID, string Quantidade, string Preco, string Descricao, string Complemento)
        {
            name = Name;
            iD = ID;
            quantidade = Quantidade;
            preco = Preco;
            descricao = Descricao;
            complemento = Complemento;
        }

        public override string ToString()
        {
            return $"{name} | {iD} | {quantidade} | R$ {preco} | {descricao} | {complemento}";
        }
    }
}
